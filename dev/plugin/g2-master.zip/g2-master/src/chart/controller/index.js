module.exports = {
  Scale: require('./scale'),
  Coord: require('./coord'),
  Axis: require('./axis'),
  Guide: require('./guide'),
  Legend: require('./legend'),
  Tooltip: require('./tooltip'),
  Event: require('./event')
};
