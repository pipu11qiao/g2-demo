const { Guide } = require('@antv/component/lib');
const RegionFilter = require('./region-filter');
Guide.RegionFilter = RegionFilter;

module.exports = Guide;
