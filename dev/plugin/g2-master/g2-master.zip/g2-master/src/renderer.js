
const G = require('@antv/g/lib');

module.exports = G;
