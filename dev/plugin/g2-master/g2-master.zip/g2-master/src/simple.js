const G2 = require('./core');

// geoms
require('./geom/interval');
require('./geom/line');
require('./geom/point');

module.exports = G2;
